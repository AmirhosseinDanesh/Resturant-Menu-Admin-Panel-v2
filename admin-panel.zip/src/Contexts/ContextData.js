import { createContext } from "react";

const ContextData = createContext(null)

export default ContextData;