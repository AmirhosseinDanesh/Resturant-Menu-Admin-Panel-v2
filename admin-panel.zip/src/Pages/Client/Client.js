import React from 'react'

export default function Client() {
  return (
    <div>Client</div>
  )
}
