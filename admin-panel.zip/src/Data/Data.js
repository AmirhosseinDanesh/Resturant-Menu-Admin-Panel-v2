const Data = {
    // url : "https://mdresturant.iran.liara.run/api"
    url : "https://mdresturant2.iran.liara.run/v1",
    urlnotV1 : "https://mdresturant2.iran.liara.run"
}

export default Data;